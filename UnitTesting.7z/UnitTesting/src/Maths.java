
public class Maths {
	
	public int fact(int num)
	{
		if(num<0)
			throw new IllegalArgumentException();
		
		if(num==0)
			return 1;
		
		return 1;
	}

}
